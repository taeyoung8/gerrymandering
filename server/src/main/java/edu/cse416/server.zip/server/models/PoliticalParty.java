package edu.cse416.server.models;

public enum PoliticalParty
{
    Democratic,
    Republican,
    Independent
}
