package edu.cse416.server.models;

public enum Mode
{
    District,
    Precinct,
    Random1,
    Random2,
    Random3
}
