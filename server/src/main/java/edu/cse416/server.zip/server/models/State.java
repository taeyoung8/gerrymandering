package edu.cse416.server.models;

public enum State
{
    MS,
    NY
}
