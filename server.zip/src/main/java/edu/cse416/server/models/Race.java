package edu.cse416.server.models;

public enum Race
{
    Asian,
    Black,
    Hispanic,
    White
}
